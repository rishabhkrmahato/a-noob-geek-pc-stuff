import yt_dlp
import re

# Function to get the best video and audio formats
def get_best_formats(url):
    ydl_opts = {
        'format': 'bestaudio/bestvideo',
        'outtmpl': 'C:\\Users\\mahat\\Videos\\%(title)s.%(ext)s',
        'quiet': True,
        'noplaylist': True,
        'restrictfilenames': True  # This option will ensure that filenames are safe
    }
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(url, download=False)
        formats = info['formats']
        best_video = max((f for f in formats if f.get('vcodec') != 'none'), key=lambda f: f.get('tbr', 0))
        best_audio = max((f for f in formats if f.get('acodec') != 'none'), key=lambda f: f.get('tbr', 0))
        return best_video['format_id'], best_audio['format_id']

# Function to download the video with the best formats
def download_video(url):
    video_format, audio_format = get_best_formats(url)
    ydl_opts = {
        'format': f'{video_format}+{audio_format}',
        'outtmpl': 'C:\\Users\\mahat\\Videos\\%(title)s.%(ext)s'
    }
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        ydl.download([url])

# Function to validate the URL format and clean it
def validate_url(input_url):
    # Remove unwanted quotes or spaces
    cleaned_url = input_url.strip().replace("'", "").replace('"', "")

    # Regex pattern to check for a valid URL
    url_pattern = re.compile(r'^(https?://)?(www\.)?([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,6}(/[^\s]*)?$')

    # Check if the cleaned URL matches the pattern
    if url_pattern.match(cleaned_url):
        # If it doesn't start with 'http' or 'https', add it
        if not cleaned_url.startswith('http'):
            cleaned_url = 'https://' + cleaned_url
        return cleaned_url
    else:
        return None

# Main function to ask for URL and download the video
if __name__ == '__main__':
    input_url = input("Enter the video URL: ")
    
    # Validate and clean the URL
    url = validate_url(input_url)

    if url:
        print(f"Downloading from: {url}")
        download_video(url)
    else:
        print("Invalid URL. Please enter a proper video URL.")
